public static class FakeLag
{
    public static int LagMilliseconds { get; set; } = 1;
    public static bool IsRunning => false;
    public static bool IsDllLoaded() => false;
    public static bool Start() => false;
    public static void Stop() { }
}
