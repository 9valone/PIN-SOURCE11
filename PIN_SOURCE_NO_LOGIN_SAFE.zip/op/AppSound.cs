using System;

public static class AppSound
{
	public static bool Muted { get; set; }

	public static void Beep(int frequency, int duration)
	{
		if (Muted)
		{
			return;
		}
		try
		{
			Console.Beep(frequency, duration);
		}
		catch
		{
		}
	}
}
