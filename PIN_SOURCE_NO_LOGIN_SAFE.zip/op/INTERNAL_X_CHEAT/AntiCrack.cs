using System;
using System.IO;

namespace INTERNAL_X_CHEAT;

public static class AntiCrack
{
	private static readonly string[] suspiciousFileNames = new string[51]
	{
		"dnspy", "dnspy-net", "dnspy-net-win64", "x64dbg", "ollydbg", "cheatengine", "httpdebuggerui", "wireshark", "fiddler", "vboxservice",
		"df5serv", "processhacker", "vboxtray", "vmtoolsd", "vmwaretray", "ida64", "ollydbg", "pestudio", "vmwareuser", "vgauthservice",
		"vmacthlp", "x96dbg", "vmsrvc", "x32dbg", "vmusrvc", "prl_cc", "prl_tools", "xenservice", "qemu-ga", "joeboxcontrol",
		"ksdumperclient", "ksdumper", "joeboxserver", "x64dbg", "dnspy", "dnspy.exe", "idax64", "devicehackerp", "scylla_x86", "scylla_x64",
		"cheat engine", "cheatengine", "cheatengine-x86_64", "ilspy", "process hacker", "dnspy-x86", "processhacker", "idapro", "idaclang.cfg", "cheatengine-i386",
		"cheatengine-x86_64-sse4-avx2"
	};

	private static readonly string[] scanLocations = new string[5]
	{
		Environment.GetFolderPath(Environment.SpecialFolder.Desktop),
		Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + "\\Downloads",
		Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
		Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),
		Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData)
	};

	public static string GetDetectedName()
	{
		string[] array = scanLocations;
		foreach (string path in array)
		{
			try
			{
				if (!Directory.Exists(path))
				{
					continue;
				}
				string[] files = Directory.GetFiles(path, "*", SearchOption.AllDirectories);
				string[] array2 = files;
				foreach (string path2 in array2)
				{
					string text = Path.GetFileName(path2).ToLower();
					string[] array3 = suspiciousFileNames;
					foreach (string text2 in array3)
					{
						if (text.Contains(text2))
						{
							return text2;
						}
					}
				}
			}
			catch
			{
			}
		}
		return null;
	}
}
