using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Windows.Forms;

namespace WindowsFormsApp2;

internal class AntiDebug
{
	private static readonly string[] BlacklistedProcesses = new string[54]
	{
		"dnspy", "dnspy-net", "dnspy-net-win64", "x64dbg", "ollydbg", "cheatengine", "httpdebuggerui", "wireshark", "fiddler", "regedit",
		"vboxservice", "df5serv", "processhacker", "vboxtray", "vmtoolsd", "vmwaretray", "ida64", "ollydbg", "pestudio", "vmwareuser",
		"vgauthservice", "vmacthlp", "x96dbg", "vmsrvc", "x32dbg", "vmusrvc", "prl_cc", "prl_tools", "xenservice", "qemu-ga",
		"joeboxcontrol", "ksdumperclient", "ksdumper", "joeboxserver", "x64dbg", "dnspy", "dnspy.exe", "idax64", "devicehackerp", "scylla_x86",
		"scylla_x64", "cheat engine", "cheatengine", "cheatengine-x86_64", "ilspy", "process hacker", "dnspy-x86", "processhacker", "ida", "idapro",
		"idaclang.cfg", "hxd", "cheatengine-i386", "cheatengine-x86_64-sse4-avx2"
	};

	private const string OriginalHash = "681B1906885226424AAB6986B3E600B841F44A4137D9674EC39AE508F8857B0A";

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern bool IsDebuggerPresent();

	public static void CheckProtection()
	{
		try
		{
			if (Debugger.IsAttached || IsDebuggerPresent())
			{
				CloseApp("Debugger detected!");
			}
			List<string> source = (from p in Process.GetProcesses()
				select p.ProcessName.ToLower()).ToList();
			string[] blacklistedProcesses = BlacklistedProcesses;
			foreach (string text in blacklistedProcesses)
			{
				string keyword = text.ToLower();
				if (source.Any((string p) => p.Contains(keyword)))
				{
					CloseApp("Cracker Detected Closing application... (" + text + ")!");
				}
			}
		}
		catch (Exception ex)
		{
			MessageBox.Show("Protection check failed: " + ex.Message, "Security Warning", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}
	}

	private static void CloseApp(string reason)
	{
		string text = reason + Environment.NewLine + "1. Cracker detected" + Environment.NewLine + "2. Please turn off debugging tools" + Environment.NewLine + "3. Sorry, application will now close.";
		MessageBox.Show(text, "Security Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
		Environment.Exit(0);
	}

	private static bool VerifyIntegrity()
	{
		string executablePath = Application.ExecutablePath;
		byte[] buffer = File.ReadAllBytes(executablePath);
		using SHA256 sHA = SHA256.Create();
		string text = BitConverter.ToString(sHA.ComputeHash(buffer)).Replace("-", "");
		return text.Equals("681B1906885226424AAB6986B3E600B841F44A4137D9674EC39AE508F8857B0A", StringComparison.OrdinalIgnoreCase);
	}
}
