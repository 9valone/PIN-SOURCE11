using System;
using System.Windows.Forms;

namespace FAKE_LAG;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        // Start directly at the main window; the login form is skipped.
        Application.Run(new Form2());
    }
}
