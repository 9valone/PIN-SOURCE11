using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Forms;
using Guna.UI2.WinForms;
using ShayanUI;

namespace FAKE_LAG;

public class Form2 : Form
{
	private bool isMuted;

	private Form3 form3;

	private IContainer components;

	private ShayanBorderless shayanBorderless1;

	private ShayanHeader shayanHeader1;

	private Label label1;

	private Panel panel2;

	private Label label4;

	private Label label3;

	private Panel panel1;

	private ShayanCheckBox shayanCheckBox1;

	private Label label2;

	private ShayanCheckBox shayanCheckBox2;

	private ShayanButton shayanButton1;

	private Label status;

	private Guna2TrackBar guna2TrackBar1;

	private Label time;

	private Panel panel3;

	private ShayanCheckBox openForm3CheckBox;

	private Label label5;

	private Label label6;

	private ShayanCheckBox muteCheckBox;

	public Form2()
	{
		InitializeComponent();
		UpdateFreezeUI(FakeLag.IsRunning);
		guna2TrackBar1.Minimum = 1;
		guna2TrackBar1.Maximum = 10;
		guna2TrackBar1.Value = 2;
		UpdateTimeLabel();
	}

	private void UpdateFreezeUI(bool isOn)
	{
	}

	private void UpdateTimeLabel()
	{
		double num = (double)guna2TrackBar1.Value * 0.5;
		time.Text = num.ToString("0.0") + "s";
	}

	private void guna2TrackBar1_Scroll(object sender, ScrollEventArgs e)
	{
		UpdateTimeLabel();
	}

	private void shayanCheckBox1_CheckedChanged(object sender, EventArgs e)
	{
		try
		{
			string folderPath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
			string text = Path.Combine(folderPath, "MR TWIST FREEZE DLL");
			Directory.CreateDirectory(text);
			Assembly executingAssembly = Assembly.GetExecutingAssembly();
			string[] manifestResourceNames = executingAssembly.GetManifestResourceNames();
			string text2 = null;
			string text3 = null;
			string[] array = manifestResourceNames;
			foreach (string text4 in array)
			{
				if (text4.EndsWith("WinDivert.dll", StringComparison.OrdinalIgnoreCase))
				{
					text2 = text4;
				}
				if (text4.EndsWith("WinDivert64.sys", StringComparison.OrdinalIgnoreCase))
				{
					text3 = text4;
				}
			}
			if (text2 != null)
			{
				string outputPath = Path.Combine(text, "WinDivert.dll");
				ExtractResource(executingAssembly, text2, outputPath);
			}
			if (text3 != null)
			{
				string outputPath2 = Path.Combine(text, "WinDivert64.sys");
				ExtractResource(executingAssembly, text3, outputPath2);
			}
			if (text2 == null)
			{
				status.Text = "WinDivert.dll resource not found!";
			}
			else if (text3 == null)
			{
				status.Text = "DLL extracted. WinDivert64.sys is not embedded.";
			}
			else
			{
				status.Text = "Files extracted successfully!";
			}
		}
		catch (Exception ex)
		{
			status.Text = "Error: " + ex.Message;
		}
	}

	private void ExtractResource(Assembly assembly, string resourceName, string outputPath)
	{
		using Stream stream = assembly.GetManifestResourceStream(resourceName);
		if (stream == null)
		{
			throw new Exception("Resource not found: " + resourceName);
		}
		using FileStream destination = new FileStream(outputPath, FileMode.Create, FileAccess.Write);
		stream.CopyTo(destination);
	}

	private void shayanCheckBox2_CheckedChanged(object sender, EventArgs e)
	{
		// Safe build: packet interception / manipulation is disabled.
		shayanCheckBox2.Checked = false;
		status.Text = "Network packet manipulation is disabled in this build.";
		UpdateFreezeUI(isOn: false);
		UpdateForm3Status(isOn: false, "Network packet manipulation disabled");
	}

	private void UpdateForm3Status(bool isOn, string logMessage)
	{
		if (form3 != null && !form3.IsDisposed)
		{
			form3.SetNetworkStatus(isOn);
			form3.AddLog(logMessage);
		}
	}

	private void shayanButton1_Click(object sender, EventArgs e)
	{
		GlobalHotkey.Bind(shayanButton1, (Control)(object)shayanCheckBox2);
	}

	private void label1_Click(object sender, EventArgs e)
	{
	}

	private void openForm3CheckBox_CheckedChanged(object sender, EventArgs e)
	{
		if (openForm3CheckBox.Checked)
		{
			if (form3 == null || form3.IsDisposed)
			{
				form3 = new Form3();
				form3.TopMost = true;
				form3.FormClosed += Form3_FormClosed;
				form3.Show();
			}
			else
			{
				form3.TopMost = true;
				form3.BringToFront();
				form3.Activate();
				form3.SetNetworkStatus(FakeLag.IsRunning);
			}
		}
		else if (form3 != null && !form3.IsDisposed)
		{
			form3.Close();
			form3 = null;
		}
	}

	private void Form3_FormClosed(object sender, FormClosedEventArgs e)
	{
		form3 = null;
		if (!IsDisposed && !Disposing)
		{
			openForm3CheckBox.Checked = false;
		}
	}

	private void panel1_Paint(object sender, PaintEventArgs e)
	{
	}

	private void time_Click(object sender, EventArgs e)
	{
	}

	private void status_Click(object sender, EventArgs e)
	{
	}

	private void muteCheckBox_CheckedChanged(object sender, EventArgs e)
	{
		AppSound.Muted = muteCheckBox.Checked;
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Expected Obj, but got Unknown
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Expected Obj, but got Unknown
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Expected Obj, but got Unknown
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Expected Obj, but got Unknown
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Expected Obj, but got Unknown
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Expected Obj, but got Unknown
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Expected Obj, but got Unknown
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Expected Obj, but got Unknown
		System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FAKE_LAG.Form2));
		this.shayanBorderless1 = new ShayanBorderless();
		this.label1 = new System.Windows.Forms.Label();
		this.shayanHeader1 = new ShayanHeader();
		this.panel1 = new System.Windows.Forms.Panel();
		this.shayanCheckBox1 = new ShayanCheckBox();
		this.label2 = new System.Windows.Forms.Label();
		this.label3 = new System.Windows.Forms.Label();
		this.panel2 = new System.Windows.Forms.Panel();
		this.shayanCheckBox2 = new ShayanCheckBox();
		this.shayanButton1 = new ShayanButton();
		this.label4 = new System.Windows.Forms.Label();
		this.status = new System.Windows.Forms.Label();
		this.guna2TrackBar1 = new Guna2TrackBar();
		this.time = new System.Windows.Forms.Label();
		this.panel3 = new System.Windows.Forms.Panel();
		this.openForm3CheckBox = new ShayanCheckBox();
		this.label5 = new System.Windows.Forms.Label();
		this.muteCheckBox = new ShayanCheckBox();
		this.label6 = new System.Windows.Forms.Label();
		this.panel1.SuspendLayout();
		this.panel2.SuspendLayout();
		this.panel3.SuspendLayout();
		base.SuspendLayout();
		this.shayanBorderless1.BlurColor = System.Drawing.Color.Black;
		this.shayanBorderless1.BlurOpacity = 150;
		this.shayanBorderless1.BorderRadius = 10;
		this.shayanBorderless1.DisableTransparency = false;
		this.shayanBorderless1.EnableBlur = false;
		this.shayanBorderless1.TargetForm = this;
		this.shayanBorderless1.Transparency = 0.9;
		this.label1.AutoSize = true;
		this.label1.Font = new System.Drawing.Font("Segoe UI", 25.8f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
		this.label1.ForeColor = System.Drawing.Color.Red;
		this.label1.Location = new System.Drawing.Point(98, 46);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(222, 59);
		this.label1.TabIndex = 0;
		this.label1.Text = "FAKE LAG";
		this.label1.Click += new System.EventHandler(this.label1_Click);
		((System.Windows.Forms.Control)(object)this.shayanHeader1).BackColor = System.Drawing.Color.Transparent;
		((System.Windows.Forms.Control)(object)this.shayanHeader1).Dock = System.Windows.Forms.DockStyle.Top;
		((System.Windows.Forms.Control)(object)this.shayanHeader1).Location = new System.Drawing.Point(0, 0);
		this.shayanHeader1.Logo = (System.Drawing.Image)resources.GetObject("shayanHeader1.Logo");
		((System.Windows.Forms.Control)(object)this.shayanHeader1).Name = "shayanHeader1";
		((System.Windows.Forms.Control)(object)this.shayanHeader1).Size = new System.Drawing.Size(423, 55);
		((System.Windows.Forms.Control)(object)this.shayanHeader1).TabIndex = 1;
		this.shayanHeader1.Title = "PAMM4 UNRE4L";
		this.panel1.Controls.Add((System.Windows.Forms.Control)(object)this.shayanCheckBox1);
		this.panel1.Controls.Add(this.label2);
		this.panel1.Location = new System.Drawing.Point(38, 124);
		this.panel1.Name = "panel1";
		this.panel1.Size = new System.Drawing.Size(344, 59);
		this.panel1.TabIndex = 2;
		this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
		((System.Windows.Forms.Control)(object)this.shayanCheckBox1).BackColor = System.Drawing.Color.Transparent;
		this.shayanCheckBox1.Checked = false;
		this.shayanCheckBox1.CheckedColor = System.Drawing.Color.Red;
		((System.Windows.Forms.Control)(object)this.shayanCheckBox1).Cursor = System.Windows.Forms.Cursors.Hand;
		((System.Windows.Forms.Control)(object)this.shayanCheckBox1).Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 36f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		((System.Windows.Forms.Control)(object)this.shayanCheckBox1).ForeColor = System.Drawing.Color.FromArgb(230, 230, 235);
		((System.Windows.Forms.Control)(object)this.shayanCheckBox1).Location = new System.Drawing.Point(298, 14);
		((System.Windows.Forms.Control)(object)this.shayanCheckBox1).Name = "shayanCheckBox1";
		((System.Windows.Forms.Control)(object)this.shayanCheckBox1).Size = new System.Drawing.Size(43, 30);
		((System.Windows.Forms.Control)(object)this.shayanCheckBox1).TabIndex = 4;
		this.shayanCheckBox1.CheckedChanged += new System.EventHandler(this.shayanCheckBox1_CheckedChanged);
		this.label2.AutoSize = true;
		this.label2.Font = new System.Drawing.Font("Segoe UI", 16.2f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
		this.label2.ForeColor = System.Drawing.Color.Red;
		this.label2.Location = new System.Drawing.Point(3, 10);
		this.label2.Name = "label2";
		this.label2.Size = new System.Drawing.Size(146, 38);
		this.label2.TabIndex = 3;
		this.label2.Text = "FAKE LAG";
		this.label3.AutoSize = true;
		this.label3.Font = new System.Drawing.Font("Segoe UI", 7.8f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
		this.label3.ForeColor = System.Drawing.Color.Red;
		this.label3.Location = new System.Drawing.Point(12, 428);
		this.label3.Name = "label3";
		this.label3.Size = new System.Drawing.Size(54, 17);
		this.label3.TabIndex = 3;
		this.label3.Text = "Status :";
		this.panel2.Controls.Add((System.Windows.Forms.Control)(object)this.shayanCheckBox2);
		this.panel2.Controls.Add((System.Windows.Forms.Control)(object)this.shayanButton1);
		this.panel2.Controls.Add(this.label4);
		this.panel2.Location = new System.Drawing.Point(38, 236);
		this.panel2.Name = "panel2";
		this.panel2.Size = new System.Drawing.Size(344, 59);
		this.panel2.TabIndex = 5;
		((System.Windows.Forms.Control)(object)this.shayanCheckBox2).BackColor = System.Drawing.Color.Transparent;
		this.shayanCheckBox2.Checked = false;
		this.shayanCheckBox2.CheckedColor = System.Drawing.Color.Red;
		((System.Windows.Forms.Control)(object)this.shayanCheckBox2).Cursor = System.Windows.Forms.Cursors.Hand;
		((System.Windows.Forms.Control)(object)this.shayanCheckBox2).Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 36f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		((System.Windows.Forms.Control)(object)this.shayanCheckBox2).ForeColor = System.Drawing.Color.FromArgb(230, 230, 235);
		((System.Windows.Forms.Control)(object)this.shayanCheckBox2).Location = new System.Drawing.Point(207, 16);
		((System.Windows.Forms.Control)(object)this.shayanCheckBox2).Name = "shayanCheckBox2";
		((System.Windows.Forms.Control)(object)this.shayanCheckBox2).Size = new System.Drawing.Size(42, 30);
		((System.Windows.Forms.Control)(object)this.shayanCheckBox2).TabIndex = 6;
		((System.Windows.Forms.Control)(object)this.shayanCheckBox2).Visible = false;
		this.shayanCheckBox2.CheckedChanged += new System.EventHandler(this.shayanCheckBox2_CheckedChanged);
		((System.Windows.Forms.Control)(object)this.shayanButton1).BackColor = System.Drawing.Color.Transparent;
		this.shayanButton1.BorderColor = System.Drawing.Color.FromArgb(180, 255, 0, 0);
		this.shayanButton1.BorderRadius = 4;
		((System.Windows.Forms.Control)(object)this.shayanButton1).Cursor = System.Windows.Forms.Cursors.Hand;
		((System.Windows.Forms.Control)(object)this.shayanButton1).Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 9.75f);
		((System.Windows.Forms.Control)(object)this.shayanButton1).ForeColor = System.Drawing.Color.White;
		this.shayanButton1.GlassColor = System.Drawing.Color.Red;
		((System.Windows.Forms.Control)(object)this.shayanButton1).Location = new System.Drawing.Point(255, 16);
		((System.Windows.Forms.Control)(object)this.shayanButton1).Name = "shayanButton1";
		((System.Windows.Forms.Control)(object)this.shayanButton1).Size = new System.Drawing.Size(73, 27);
		((System.Windows.Forms.Control)(object)this.shayanButton1).TabIndex = 4;
		((System.Windows.Forms.Control)(object)this.shayanButton1).Text = "N/A";
		((System.Windows.Forms.Control)(object)this.shayanButton1).Click += new System.EventHandler(this.shayanButton1_Click);
		this.label4.AutoSize = true;
		this.label4.Font = new System.Drawing.Font("Segoe UI", 16.2f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
		this.label4.ForeColor = System.Drawing.Color.Red;
		this.label4.Location = new System.Drawing.Point(3, 10);
		this.label4.Name = "label4";
		this.label4.Size = new System.Drawing.Size(124, 38);
		this.label4.TabIndex = 3;
		this.label4.Text = "HOTKEY";
		this.status.AutoSize = true;
		this.status.Font = new System.Drawing.Font("Segoe UI", 7.8f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
		this.status.ForeColor = System.Drawing.Color.Red;
		this.status.Location = new System.Drawing.Point(72, 428);
		this.status.Name = "status";
		this.status.Size = new System.Drawing.Size(33, 17);
		this.status.TabIndex = 6;
		this.status.Text = "N/A";
		this.status.Click += new System.EventHandler(this.status_Click);
		((System.Windows.Forms.Control)(object)this.guna2TrackBar1).Location = new System.Drawing.Point(48, 198);
		((System.Windows.Forms.Control)(object)this.guna2TrackBar1).Name = "guna2TrackBar1";
		((System.Windows.Forms.Control)(object)this.guna2TrackBar1).Size = new System.Drawing.Size(272, 23);
		((System.Windows.Forms.Control)(object)this.guna2TrackBar1).TabIndex = 7;
		this.guna2TrackBar1.ThumbColor = System.Drawing.Color.Red;
		this.guna2TrackBar1.Scroll += new System.Windows.Forms.ScrollEventHandler(this.guna2TrackBar1_Scroll);
		this.time.AutoSize = true;
		this.time.Font = new System.Drawing.Font("Segoe UI", 7.8f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
		this.time.ForeColor = System.Drawing.Color.Red;
		this.time.Location = new System.Drawing.Point(346, 204);
		this.time.Name = "time";
		this.time.Size = new System.Drawing.Size(33, 17);
		this.time.TabIndex = 8;
		this.time.Text = "N/A";
		this.time.Click += new System.EventHandler(this.time_Click);
		this.panel3.Controls.Add((System.Windows.Forms.Control)(object)this.openForm3CheckBox);
		this.panel3.Controls.Add(this.label5);
		this.panel3.Location = new System.Drawing.Point(38, 325);
		this.panel3.Name = "panel3";
		this.panel3.Size = new System.Drawing.Size(344, 59);
		this.panel3.TabIndex = 5;
		((System.Windows.Forms.Control)(object)this.openForm3CheckBox).BackColor = System.Drawing.Color.Transparent;
		this.openForm3CheckBox.Checked = false;
		this.openForm3CheckBox.CheckedColor = System.Drawing.Color.Red;
		((System.Windows.Forms.Control)(object)this.openForm3CheckBox).Cursor = System.Windows.Forms.Cursors.Hand;
		((System.Windows.Forms.Control)(object)this.openForm3CheckBox).Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 36f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		((System.Windows.Forms.Control)(object)this.openForm3CheckBox).ForeColor = System.Drawing.Color.FromArgb(230, 230, 235);
		((System.Windows.Forms.Control)(object)this.openForm3CheckBox).Location = new System.Drawing.Point(298, 14);
		((System.Windows.Forms.Control)(object)this.openForm3CheckBox).Name = "openForm3CheckBox";
		((System.Windows.Forms.Control)(object)this.openForm3CheckBox).Size = new System.Drawing.Size(43, 30);
		((System.Windows.Forms.Control)(object)this.openForm3CheckBox).TabIndex = 4;
		this.openForm3CheckBox.CheckedChanged += new System.EventHandler(this.openForm3CheckBox_CheckedChanged);
		this.label5.AutoSize = true;
		this.label5.Font = new System.Drawing.Font("Segoe UI", 16.2f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
		this.label5.ForeColor = System.Drawing.Color.Red;
		this.label5.Location = new System.Drawing.Point(3, 10);
		this.label5.Name = "label5";
		this.label5.Size = new System.Drawing.Size(170, 38);
		this.label5.TabIndex = 3;
		this.label5.Text = "OPEN LOGS";
		((System.Windows.Forms.Control)(object)this.muteCheckBox).BackColor = System.Drawing.Color.Transparent;
		this.muteCheckBox.Checked = false;
		this.muteCheckBox.CheckedColor = System.Drawing.Color.Red;
		((System.Windows.Forms.Control)(object)this.muteCheckBox).Cursor = System.Windows.Forms.Cursors.Hand;
		((System.Windows.Forms.Control)(object)this.muteCheckBox).Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 36f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		((System.Windows.Forms.Control)(object)this.muteCheckBox).ForeColor = System.Drawing.Color.FromArgb(230, 230, 235);
		((System.Windows.Forms.Control)(object)this.muteCheckBox).Location = new System.Drawing.Point(336, 390);
		((System.Windows.Forms.Control)(object)this.muteCheckBox).Name = "muteCheckBox";
		((System.Windows.Forms.Control)(object)this.muteCheckBox).Size = new System.Drawing.Size(43, 30);
		((System.Windows.Forms.Control)(object)this.muteCheckBox).TabIndex = 5;
		((System.Windows.Forms.Control)(object)this.muteCheckBox).Text = "Mute Sounds";
		this.muteCheckBox.CheckedChanged += new System.EventHandler(this.muteCheckBox_CheckedChanged);
		this.label6.AutoSize = true;
		this.label6.Font = new System.Drawing.Font("Segoe UI", 7.8f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
		this.label6.ForeColor = System.Drawing.Color.Red;
		this.label6.Location = new System.Drawing.Point(261, 399);
		this.label6.Name = "label6";
		this.label6.Size = new System.Drawing.Size(40, 17);
		this.label6.TabIndex = 5;
		this.label6.Text = "Mute";
		base.AutoScaleDimensions = new System.Drawing.SizeF(8f, 16f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
		base.ClientSize = new System.Drawing.Size(423, 454);
		base.Controls.Add(this.label6);
		base.Controls.Add((System.Windows.Forms.Control)(object)this.muteCheckBox);
		base.Controls.Add(this.panel3);
		base.Controls.Add((System.Windows.Forms.Control)(object)this.guna2TrackBar1);
		base.Controls.Add(this.time);
		base.Controls.Add(this.status);
		base.Controls.Add(this.panel2);
		base.Controls.Add(this.label3);
		base.Controls.Add(this.panel1);
		base.Controls.Add((System.Windows.Forms.Control)(object)this.shayanHeader1);
		base.Controls.Add(this.label1);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
		base.Name = "Form2";
		base.Opacity = 0.9;
		this.Text = "Form1";
		this.panel1.ResumeLayout(false);
		this.panel1.PerformLayout();
		this.panel2.ResumeLayout(false);
		this.panel2.PerformLayout();
		this.panel3.ResumeLayout(false);
		this.panel3.PerformLayout();
		base.ResumeLayout(false);
		base.PerformLayout();
	}
}
