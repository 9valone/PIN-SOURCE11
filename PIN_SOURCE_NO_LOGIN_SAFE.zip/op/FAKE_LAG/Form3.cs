using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Guna.UI2.WinForms;

namespace FAKE_LAG;

public class Form3 : Form
{
	private IContainer components;

	private Guna2BorderlessForm guna2BorderlessForm1;

	private Label label1;

	private Guna2Panel statusLight;

	private Guna2TextBox logBox;

	private Guna2HtmlLabel statusLabel;

	public Form3()
	{
		InitializeComponent();
		SetNetworkStatus(FakeLag.IsRunning);
		AddLog("System ready.");
	}

	public void SetNetworkStatus(bool isOn)
	{
		if (InvokeRequired)
		{
			Invoke((Action)(() =>
			{
				SetNetworkStatus(isOn);
			}));
			return;
		}
		if (isOn)
		{
			statusLight.FillColor = Color.LimeGreen;
			((Control)(object)statusLabel).Text = "STATUS: ON";
			((Control)(object)statusLabel).ForeColor = Color.LimeGreen;
		}
		else
		{
			statusLight.FillColor = Color.Red;
			((Control)(object)statusLabel).Text = "STATUS: OFF";
			((Control)(object)statusLabel).ForeColor = Color.Red;
		}
		((Control)(object)statusLight).Refresh();
		((Control)(object)statusLabel).Refresh();
	}

	public void AddLog(string message)
	{
		if (InvokeRequired)
		{
			Invoke((Action)(() =>
			{
				AddLog(message);
			}));
			return;
		}
		string text = DateTime.Now.ToString("HH:mm:ss");
		logBox.AppendText("[" + text + "] " + message + Environment.NewLine);
		logBox.SelectionStart = ((Control)(object)logBox).Text.Length;
		logBox.ScrollToCaret();
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Expected Obj, but got Unknown
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Expected Obj, but got Unknown
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Expected Obj, but got Unknown
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Expected Obj, but got Unknown
		this.components = new System.ComponentModel.Container();
		this.guna2BorderlessForm1 = new Guna2BorderlessForm(this.components);
		this.label1 = new System.Windows.Forms.Label();
		this.statusLight = new Guna2Panel();
		this.statusLabel = new Guna2HtmlLabel();
		this.logBox = new Guna2TextBox();
		base.SuspendLayout();
		this.guna2BorderlessForm1.ContainerControl = this;
		this.guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6;
		this.guna2BorderlessForm1.TransparentWhileDrag = true;
		this.label1.AutoSize = true;
		this.label1.Font = new System.Drawing.Font("Segoe UI", 13.8f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
		this.label1.ForeColor = System.Drawing.Color.Red;
		this.label1.Location = new System.Drawing.Point(54, 9);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(206, 31);
		this.label1.TabIndex = 1;
		this.label1.Text = "FAKE LAG STATUS";
		((System.Windows.Forms.Control)(object)this.statusLight).BackColor = System.Drawing.Color.Black;
		this.statusLight.BorderRadius = 12;
		this.statusLight.FillColor = System.Drawing.Color.Red;
		((System.Windows.Forms.Control)(object)this.statusLight).Location = new System.Drawing.Point(262, 84);
		((System.Windows.Forms.Control)(object)this.statusLight).Name = "statusLight";
		((System.Windows.Forms.Control)(object)this.statusLight).Size = new System.Drawing.Size(24, 24);
		((System.Windows.Forms.Control)(object)this.statusLight).TabIndex = 2;
		((System.Windows.Forms.Control)(object)this.statusLabel).BackColor = System.Drawing.Color.Transparent;
		((System.Windows.Forms.Control)(object)this.statusLabel).Font = new System.Drawing.Font("Microsoft Sans Serif", 12f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
		((System.Windows.Forms.Control)(object)this.statusLabel).ForeColor = System.Drawing.Color.White;
		((System.Windows.Forms.Control)(object)this.statusLabel).Location = new System.Drawing.Point(21, 84);
		((System.Windows.Forms.Control)(object)this.statusLabel).Name = "statusLabel";
		((System.Windows.Forms.Control)(object)this.statusLabel).Size = new System.Drawing.Size(91, 27);
		((System.Windows.Forms.Control)(object)this.statusLabel).TabIndex = 3;
		((System.Windows.Forms.Control)(object)this.statusLabel).Text = "STATUS";
		((System.Windows.Forms.Control)(object)this.logBox).Cursor = System.Windows.Forms.Cursors.IBeam;
		this.logBox.DefaultText = "";
		this.logBox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(208, 208, 208);
		this.logBox.DisabledState.FillColor = System.Drawing.Color.FromArgb(226, 226, 226);
		this.logBox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(138, 138, 138);
		this.logBox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(138, 138, 138);
		this.logBox.FillColor = System.Drawing.Color.Black;
		this.logBox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(94, 148, 255);
		((System.Windows.Forms.Control)(object)this.logBox).Font = new System.Drawing.Font("Segoe UI", 9f);
		((System.Windows.Forms.Control)(object)this.logBox).ForeColor = System.Drawing.Color.White;
		this.logBox.HoverState.BorderColor = System.Drawing.Color.FromArgb(94, 148, 255);
		((System.Windows.Forms.Control)(object)this.logBox).Location = new System.Drawing.Point(10, 138);
		((System.Windows.Forms.Control)(object)this.logBox).Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
		this.logBox.Multiline = true;
		((System.Windows.Forms.Control)(object)this.logBox).Name = "logBox";
		this.logBox.PlaceholderText = "";
		this.logBox.ReadOnly = true;
		this.logBox.SelectedText = "";
		((System.Windows.Forms.Control)(object)this.logBox).Size = new System.Drawing.Size(300, 150);
		((System.Windows.Forms.Control)(object)this.logBox).TabIndex = 4;
		base.AutoScaleDimensions = new System.Drawing.SizeF(8f, 16f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		this.BackColor = System.Drawing.Color.Black;
		base.ClientSize = new System.Drawing.Size(319, 301);
		base.Controls.Add((System.Windows.Forms.Control)(object)this.logBox);
		base.Controls.Add((System.Windows.Forms.Control)(object)this.statusLabel);
		base.Controls.Add((System.Windows.Forms.Control)(object)this.statusLight);
		base.Controls.Add(this.label1);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
		base.Name = "Form3";
		this.Text = "Form3";
		base.ResumeLayout(false);
		base.PerformLayout();
	}
}
