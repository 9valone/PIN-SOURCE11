using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using FAKE_LAG.Properties;
using Guna.UI2.WinForms;
using KeyAuth;
using ShayanUI;

namespace FAKE_LAG;

public class Form1 : Form
{
	private class Particle
	{
		public float X;

		public float Y;

		public float SpeedX;

		public float SpeedY;

		public float Size;

		public int Alpha;
	}

	public static api KeyAuthApp = new api("FAKE_LAG", "ve54J44k2m", "1.0");

	private readonly List<Particle> particles = new List<Particle>();

	private readonly Random random = new Random();

	private Timer particleTimer;

	private IContainer components;

	private Guna2BorderlessForm guna2BorderlessForm1;

	private Guna2TextBox Pass;

	private Guna2TextBox User;

	private Guna2TextBox guna2TextBox4;

	private Guna2Button guna2Button1;

	private ShayanHeader shayanHeader1;

	private Label label1;

	private Guna2Button guna2Button2;

	private Label label2;

	private Label status;

	private Label label3;

	public Form1()
	{
		InitializeComponent();
		DoubleBuffered = true;
		SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		LoadInformation();
		KeyAuthApp.init();
		CreateParticles();
		particleTimer = new Timer();
		particleTimer.Interval = 16;
		particleTimer.Tick += ParticleTimer_Tick;
		particleTimer.Start();
	}

	private void CreateParticles()
	{
		particles.Clear();
		for (int i = 0; i < 60; i++)
		{
			Particle particle = new Particle();
			particle.X = random.Next(0, Math.Max(1, ClientSize.Width));
			particle.Y = random.Next(0, Math.Max(1, ClientSize.Height));
			particle.SpeedX = (float)(random.NextDouble() * 1.2 - 0.6);
			particle.SpeedY = (float)(random.NextDouble() * 1.2 - 0.6);
			particle.Size = random.Next(2, 6);
			particle.Alpha = random.Next(80, 220);
			particles.Add(particle);
		}
	}

	private void ParticleTimer_Tick(object sender, EventArgs e)
	{
		foreach (Particle particle in particles)
		{
			particle.X += particle.SpeedX;
			particle.Y += particle.SpeedY;
			if (particle.X < -10f)
			{
				particle.X = ClientSize.Width + 10;
			}
			if (particle.X > (float)(ClientSize.Width + 10))
			{
				particle.X = -10f;
			}
			if (particle.Y < -10f)
			{
				particle.Y = ClientSize.Height + 10;
			}
			if (particle.Y > (float)(ClientSize.Height + 10))
			{
				particle.Y = -10f;
			}
		}
		Invalidate();
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		base.OnPaint(e);
		Graphics graphics = e.Graphics;
		graphics.SmoothingMode = SmoothingMode.AntiAlias;
		foreach (Particle particle in particles)
		{
			float size = particle.Size;
			using (SolidBrush brush = new SolidBrush(Color.FromArgb(particle.Alpha / 4, 255, 0, 0)))
			{
				float num = size * 4f;
				graphics.FillEllipse(brush, particle.X - num / 2f, particle.Y - num / 2f, num, num);
			}
			using SolidBrush brush2 = new SolidBrush(Color.FromArgb(particle.Alpha, 255, 20, 20));
			graphics.FillEllipse(brush2, particle.X - size / 2f, particle.Y - size / 2f, size, size);
		}
	}

	private void SaveUserAndPass()
	{
		Settings.Default.User = ((Control)(object)User).Text;
		Settings.Default.Pass = ((Control)(object)Pass).Text;
		Settings.Default.Save();
	}

	private void LoadInformation()
	{
		((Control)(object)User).Text = Settings.Default.User;
		((Control)(object)Pass).Text = Settings.Default.Pass;
	}

	private void guna2Button1_Click(object sender, EventArgs e)
	{
		KeyAuthApp.login(((Control)(object)User).Text, ((Control)(object)Pass).Text);
		SaveUserAndPass();
		if (KeyAuthApp.response.success)
		{
			Form2 form = new Form2();
			form.Show();
			Hide();
		}
		else
		{
			status.Text = KeyAuthApp.response.message;
			Console.Beep(400, 300);
		}
	}

	private void guna2TextBox1_TextChanged(object sender, EventArgs e)
	{
	}

	private void guna2TextBox3_TextChanged(object sender, EventArgs e)
	{
	}

	private void guna2TextBox4_TextChanged(object sender, EventArgs e)
	{
	}

	private void shayanHeader1_Load(object sender, EventArgs e)
	{
	}

	protected override void OnResize(EventArgs e)
	{
		base.OnResize(e);
		if (particles == null || particles.Count <= 0)
		{
			return;
		}
		foreach (Particle particle in particles)
		{
			if (particle.X > (float)ClientSize.Width)
			{
				particle.X = random.Next(0, Math.Max(1, ClientSize.Width));
			}
			if (particle.Y > (float)ClientSize.Height)
			{
				particle.Y = random.Next(0, Math.Max(1, ClientSize.Height));
			}
		}
	}

	protected override void OnFormClosed(FormClosedEventArgs e)
	{
		if (particleTimer != null)
		{
			particleTimer.Stop();
			particleTimer.Dispose();
		}
		base.OnFormClosed(e);
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Expected Obj, but got Unknown
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Expected Obj, but got Unknown
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Expected Obj, but got Unknown
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Expected Obj, but got Unknown
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Expected Obj, but got Unknown
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Expected Obj, but got Unknown
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Expected Obj, but got Unknown
		this.components = new System.ComponentModel.Container();
		System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FAKE_LAG.Form1));
		this.guna2BorderlessForm1 = new Guna2BorderlessForm(this.components);
		this.User = new Guna2TextBox();
		this.Pass = new Guna2TextBox();
		this.guna2TextBox4 = new Guna2TextBox();
		this.guna2Button1 = new Guna2Button();
		this.shayanHeader1 = new ShayanHeader();
		this.guna2Button2 = new Guna2Button();
		this.label1 = new System.Windows.Forms.Label();
		this.label2 = new System.Windows.Forms.Label();
		this.label3 = new System.Windows.Forms.Label();
		this.status = new System.Windows.Forms.Label();
		base.SuspendLayout();
		this.guna2BorderlessForm1.ContainerControl = this;
		this.guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6;
		this.guna2BorderlessForm1.TransparentWhileDrag = true;
		this.User.BorderColor = System.Drawing.Color.Red;
		((System.Windows.Forms.Control)(object)this.User).Cursor = System.Windows.Forms.Cursors.IBeam;
		this.User.DefaultText = "";
		this.User.DisabledState.BorderColor = System.Drawing.Color.FromArgb(208, 208, 208);
		this.User.DisabledState.FillColor = System.Drawing.Color.FromArgb(226, 226, 226);
		this.User.DisabledState.ForeColor = System.Drawing.Color.FromArgb(138, 138, 138);
		this.User.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(138, 138, 138);
		this.User.FillColor = System.Drawing.Color.Transparent;
		this.User.FocusedState.BorderColor = System.Drawing.Color.FromArgb(94, 148, 255);
		((System.Windows.Forms.Control)(object)this.User).Font = new System.Drawing.Font("Segoe UI", 9f);
		((System.Windows.Forms.Control)(object)this.User).ForeColor = System.Drawing.Color.White;
		this.User.HoverState.BorderColor = System.Drawing.Color.FromArgb(94, 148, 255);
		((System.Windows.Forms.Control)(object)this.User).Location = new System.Drawing.Point(85, 153);
		((System.Windows.Forms.Control)(object)this.User).Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
		((System.Windows.Forms.Control)(object)this.User).Name = "User";
		this.User.PlaceholderForeColor = System.Drawing.Color.White;
		this.User.PlaceholderText = "USERNAME";
		this.User.SelectedText = "";
		((System.Windows.Forms.Control)(object)this.User).Size = new System.Drawing.Size(375, 46);
		((System.Windows.Forms.Control)(object)this.User).TabIndex = 1;
		this.Pass.BorderColor = System.Drawing.Color.Red;
		((System.Windows.Forms.Control)(object)this.Pass).Cursor = System.Windows.Forms.Cursors.IBeam;
		this.Pass.DefaultText = "";
		this.Pass.DisabledState.BorderColor = System.Drawing.Color.FromArgb(208, 208, 208);
		this.Pass.DisabledState.FillColor = System.Drawing.Color.FromArgb(226, 226, 226);
		this.Pass.DisabledState.ForeColor = System.Drawing.Color.FromArgb(138, 138, 138);
		this.Pass.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(138, 138, 138);
		this.Pass.FillColor = System.Drawing.Color.Transparent;
		this.Pass.FocusedState.BorderColor = System.Drawing.Color.FromArgb(94, 148, 255);
		((System.Windows.Forms.Control)(object)this.Pass).Font = new System.Drawing.Font("Segoe UI", 9f);
		((System.Windows.Forms.Control)(object)this.Pass).ForeColor = System.Drawing.Color.White;
		this.Pass.HoverState.BorderColor = System.Drawing.Color.FromArgb(94, 148, 255);
		((System.Windows.Forms.Control)(object)this.Pass).Location = new System.Drawing.Point(85, 207);
		((System.Windows.Forms.Control)(object)this.Pass).Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
		((System.Windows.Forms.Control)(object)this.Pass).Name = "Pass";
		this.Pass.PlaceholderForeColor = System.Drawing.Color.White;
		this.Pass.PlaceholderText = "PASSWORD";
		this.Pass.SelectedText = "";
		((System.Windows.Forms.Control)(object)this.Pass).Size = new System.Drawing.Size(375, 46);
		((System.Windows.Forms.Control)(object)this.Pass).TabIndex = 2;
		this.Pass.TextChanged += new System.EventHandler(this.guna2TextBox3_TextChanged);
		this.guna2TextBox4.BorderColor = System.Drawing.Color.Red;
		((System.Windows.Forms.Control)(object)this.guna2TextBox4).Cursor = System.Windows.Forms.Cursors.IBeam;
		this.guna2TextBox4.DefaultText = "";
		this.guna2TextBox4.DisabledState.BorderColor = System.Drawing.Color.FromArgb(208, 208, 208);
		this.guna2TextBox4.DisabledState.FillColor = System.Drawing.Color.FromArgb(226, 226, 226);
		this.guna2TextBox4.DisabledState.ForeColor = System.Drawing.Color.FromArgb(138, 138, 138);
		this.guna2TextBox4.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(138, 138, 138);
		this.guna2TextBox4.FillColor = System.Drawing.Color.Transparent;
		this.guna2TextBox4.FocusedState.BorderColor = System.Drawing.Color.FromArgb(94, 148, 255);
		((System.Windows.Forms.Control)(object)this.guna2TextBox4).Font = new System.Drawing.Font("Segoe UI", 9f);
		((System.Windows.Forms.Control)(object)this.guna2TextBox4).ForeColor = System.Drawing.Color.White;
		this.guna2TextBox4.HoverState.BorderColor = System.Drawing.Color.FromArgb(94, 148, 255);
		((System.Windows.Forms.Control)(object)this.guna2TextBox4).Location = new System.Drawing.Point(85, 256);
		((System.Windows.Forms.Control)(object)this.guna2TextBox4).Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
		((System.Windows.Forms.Control)(object)this.guna2TextBox4).Name = "guna2TextBox4";
		this.guna2TextBox4.PlaceholderForeColor = System.Drawing.Color.White;
		this.guna2TextBox4.PlaceholderText = "LICENSE KEY";
		this.guna2TextBox4.SelectedText = "";
		((System.Windows.Forms.Control)(object)this.guna2TextBox4).Size = new System.Drawing.Size(375, 46);
		((System.Windows.Forms.Control)(object)this.guna2TextBox4).TabIndex = 3;
		this.guna2TextBox4.TextChanged += new System.EventHandler(this.guna2TextBox4_TextChanged);
		this.guna2Button1.BorderColor = System.Drawing.Color.Red;
		this.guna2Button1.BorderThickness = 1;
		this.guna2Button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
		this.guna2Button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
		this.guna2Button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(169, 169, 169);
		this.guna2Button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(141, 141, 141);
		this.guna2Button1.FillColor = System.Drawing.Color.Black;
		((System.Windows.Forms.Control)(object)this.guna2Button1).Font = new System.Drawing.Font("Segoe UI", 9f);
		((System.Windows.Forms.Control)(object)this.guna2Button1).ForeColor = System.Drawing.Color.White;
		((System.Windows.Forms.Control)(object)this.guna2Button1).Location = new System.Drawing.Point(172, 325);
		((System.Windows.Forms.Control)(object)this.guna2Button1).Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
		((System.Windows.Forms.Control)(object)this.guna2Button1).Name = "guna2Button1";
		((System.Windows.Forms.Control)(object)this.guna2Button1).Size = new System.Drawing.Size(180, 46);
		((System.Windows.Forms.Control)(object)this.guna2Button1).TabIndex = 4;
		((System.Windows.Forms.Control)(object)this.guna2Button1).Text = "LOGIN";
		((System.Windows.Forms.Control)(object)this.guna2Button1).Click += new System.EventHandler(this.guna2Button1_Click);
		((System.Windows.Forms.Control)(object)this.shayanHeader1).BackColor = System.Drawing.Color.Transparent;
		((System.Windows.Forms.Control)(object)this.shayanHeader1).Dock = System.Windows.Forms.DockStyle.Top;
		((System.Windows.Forms.Control)(object)this.shayanHeader1).Location = new System.Drawing.Point(0, 0);
		this.shayanHeader1.Logo = (System.Drawing.Image)resources.GetObject("shayanHeader1.Logo");
		((System.Windows.Forms.Control)(object)this.shayanHeader1).Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
		((System.Windows.Forms.Control)(object)this.shayanHeader1).Name = "shayanHeader1";
		((System.Windows.Forms.Control)(object)this.shayanHeader1).Size = new System.Drawing.Size(541, 58);
		((System.Windows.Forms.Control)(object)this.shayanHeader1).TabIndex = 6;
		this.shayanHeader1.Title = "PAMM4 UNRE4L";
		((System.Windows.Forms.UserControl)(object)this.shayanHeader1).Load += new System.EventHandler(this.shayanHeader1_Load);
		this.guna2Button2.BorderColor = System.Drawing.Color.Red;
		this.guna2Button2.BorderThickness = 1;
		this.guna2Button2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
		this.guna2Button2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
		this.guna2Button2.DisabledState.FillColor = System.Drawing.Color.FromArgb(169, 169, 169);
		this.guna2Button2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(141, 141, 141);
		this.guna2Button2.FillColor = System.Drawing.Color.Black;
		((System.Windows.Forms.Control)(object)this.guna2Button2).Font = new System.Drawing.Font("Segoe UI", 9f);
		((System.Windows.Forms.Control)(object)this.guna2Button2).ForeColor = System.Drawing.Color.White;
		((System.Windows.Forms.Control)(object)this.guna2Button2).Location = new System.Drawing.Point(172, 377);
		((System.Windows.Forms.Control)(object)this.guna2Button2).Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
		((System.Windows.Forms.Control)(object)this.guna2Button2).Name = "guna2Button2";
		((System.Windows.Forms.Control)(object)this.guna2Button2).Size = new System.Drawing.Size(180, 46);
		((System.Windows.Forms.Control)(object)this.guna2Button2).TabIndex = 7;
		((System.Windows.Forms.Control)(object)this.guna2Button2).Text = "REGISTER";
		this.label1.AutoSize = true;
		this.label1.Location = new System.Drawing.Point(12, 425);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(44, 16);
		this.label1.TabIndex = 8;
		this.label1.Text = "label1";
		this.label2.AutoSize = true;
		this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
		this.label2.ForeColor = System.Drawing.Color.Red;
		this.label2.Location = new System.Drawing.Point(143, 78);
		this.label2.Name = "label2";
		this.label2.Size = new System.Drawing.Size(259, 54);
		this.label2.TabIndex = 9;
		this.label2.Text = "FAKE LAG";
		this.label3.AutoSize = true;
		this.label3.Location = new System.Drawing.Point(407, 411);
		this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.label3.Name = "label3";
		this.label3.Size = new System.Drawing.Size(44, 16);
		this.label3.TabIndex = 10;
		this.label3.Text = "label3";
		this.status.AutoSize = true;
		this.status.ForeColor = System.Drawing.Color.Red;
		this.status.Location = new System.Drawing.Point(12, 425);
		this.status.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
		this.status.Name = "status";
		this.status.Size = new System.Drawing.Size(30, 16);
		this.status.TabIndex = 11;
		this.status.Text = "N/A";
		base.AutoScaleDimensions = new System.Drawing.SizeF(8f, 16f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		this.BackColor = System.Drawing.Color.Black;
		base.ClientSize = new System.Drawing.Size(541, 450);
		base.Controls.Add(this.status);
		base.Controls.Add(this.label3);
		base.Controls.Add(this.label2);
		base.Controls.Add(this.label1);
		base.Controls.Add((System.Windows.Forms.Control)(object)this.guna2Button2);
		base.Controls.Add((System.Windows.Forms.Control)(object)this.shayanHeader1);
		base.Controls.Add((System.Windows.Forms.Control)(object)this.guna2Button1);
		base.Controls.Add((System.Windows.Forms.Control)(object)this.guna2TextBox4);
		base.Controls.Add((System.Windows.Forms.Control)(object)this.Pass);
		base.Controls.Add((System.Windows.Forms.Control)(object)this.User);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
		base.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
		base.Name = "Form1";
		this.Text = "Form2";
		base.ResumeLayout(false);
		base.PerformLayout();
	}
}
