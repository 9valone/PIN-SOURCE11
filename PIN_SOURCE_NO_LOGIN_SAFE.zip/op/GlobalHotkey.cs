using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;

public class GlobalHotkey : NativeWindow
{
	private delegate IntPtr LowLevelMouseProc(int nCode, IntPtr wParam, IntPtr lParam);

	private const int WH_KEYBOARD_LL = 13;

	private const int WH_MOUSE_LL = 14;

	private const int WM_HOTKEY = 786;

	private const int WM_LBUTTONDOWN = 513;

	private const int WM_RBUTTONDOWN = 516;

	private const int WM_MBUTTONDOWN = 519;

	private const int WM_XBUTTONDOWN = 523;

	private const int XBUTTON1 = 1;

	private const int XBUTTON2 = 2;

	private static GlobalHotkey _instance;

	private static IntPtr _mouseHook = IntPtr.Zero;

	private static LowLevelMouseProc _mouseProc;

	private static readonly Dictionary<int, Control> _targets = new Dictionary<int, Control>();

	private static readonly Dictionary<int, Control> _buttons = new Dictionary<int, Control>();

	private static readonly Dictionary<int, MouseButtons> _mouseBindings = new Dictionary<int, MouseButtons>();

	private static int _captureId = -1;

	private static Control _captureButton;

	private static Control _captureTarget;

	private static Form _captureForm;

	[DllImport("user32.dll")]
	private static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);

	[DllImport("user32.dll")]
	private static extern bool UnregisterHotKey(IntPtr hWnd, int id);

	[DllImport("user32.dll", SetLastError = true)]
	private static extern IntPtr SetWindowsHookEx(int idHook, Delegate lpfn, IntPtr hMod, uint dwThreadId);

	[DllImport("user32.dll", SetLastError = true)]
	private static extern bool UnhookWindowsHookEx(IntPtr hhk);

	[DllImport("user32.dll")]
	private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

	[DllImport("kernel32.dll")]
	private static extern IntPtr GetModuleHandle(string lpModuleName);

	public static void Bind(object sender, Control target)
	{
		Control button = sender as Control;
		if (button == null || target == null)
		{
			return;
		}
		Form form = button.FindForm();
		if (form == null)
		{
			return;
		}
		if (_instance == null)
		{
			_instance = new GlobalHotkey();
			_instance.AssignHandle(form.Handle);
		}
		int id = button.GetHashCode();
		RemoveBinding(id);
		_captureId = id;
		_captureButton = button;
		_captureTarget = target;
		_captureForm = form;
		button.Text = "...";
		form.KeyPreview = true;
		KeyEventHandler keyHandler = null;
		keyHandler = (object s, KeyEventArgs e) =>
		{
			if (_captureId == id && _captureButton == button)
			{
				if (e.KeyCode == Keys.Escape)
				{
					button.Text = "N/A";
					ClearCapture();
					form.KeyDown -= keyHandler;
				}
				else if (!RegisterHotKey(_instance.Handle, id, 0u, (uint)e.KeyCode))
				{
					button.Text = "N/A";
					ClearCapture();
					form.KeyDown -= keyHandler;
				}
				else
				{
					_targets[id] = target;
					_buttons[id] = button;
					_mouseBindings.Remove(id);
					button.Text = e.KeyCode.ToString();
					ClearCapture();
					form.KeyDown -= keyHandler;
				}
			}
		};
		form.KeyDown += keyHandler;
		InstallMouseHook();
	}

	private static void InstallMouseHook()
	{
		if (_mouseHook != IntPtr.Zero)
		{
			return;
		}
		_mouseProc = MouseHookCallback;
		using Process process = Process.GetCurrentProcess();
		using ProcessModule processModule = process.MainModule;
		IntPtr moduleHandle = GetModuleHandle(processModule.ModuleName);
		_mouseHook = SetWindowsHookEx(14, _mouseProc, moduleHandle, 0u);
	}

	private static IntPtr MouseHookCallback(int nCode, IntPtr wParam, IntPtr lParam)
	{
		if (nCode >= 0)
		{
			int num = wParam.ToInt32();
			MouseButtons mouseButtons = MouseButtons.None;
			switch (num)
			{
			case 513:
				mouseButtons = MouseButtons.Left;
				break;
			case 516:
				mouseButtons = MouseButtons.Right;
				break;
			case 519:
				mouseButtons = MouseButtons.Middle;
				break;
			case 523:
			{
				int num2 = Marshal.ReadInt32(lParam, 8);
				switch ((num2 >> 16) & 0xFFFF)
				{
				case 1:
					mouseButtons = MouseButtons.XButton1;
					break;
				case 2:
					mouseButtons = MouseButtons.XButton2;
					break;
				}
				break;
			}
			}
			if (mouseButtons != MouseButtons.None)
			{
				if (_captureId != -1 && _captureButton != null)
				{
					CaptureMouseBinding(mouseButtons);
					return CallNextHookEx(_mouseHook, nCode, wParam, lParam);
				}
				TriggerMouseBinding(mouseButtons);
			}
		}
		return CallNextHookEx(_mouseHook, nCode, wParam, lParam);
	}

	private static void CaptureMouseBinding(MouseButtons mouseButton)
	{
		int captureId = _captureId;
		Control captureButton = _captureButton;
		Control captureTarget = _captureTarget;
		if (_instance != null && _instance.Handle != IntPtr.Zero)
		{
			UnregisterHotKey(_instance.Handle, captureId);
		}
		_targets[captureId] = captureTarget;
		_buttons[captureId] = captureButton;
		_mouseBindings[captureId] = mouseButton;
		captureButton.Text = GetMouseButtonName(mouseButton);
		ClearCapture();
	}

	private static void TriggerMouseBinding(MouseButtons mouseButton)
	{
		foreach (KeyValuePair<int, MouseButtons> item in new List<KeyValuePair<int, MouseButtons>>(_mouseBindings))
		{
			if (item.Value == mouseButton)
			{
				int key = item.Key;
				if (_targets.TryGetValue(key, out var value))
				{
					ToggleTarget(value);
				}
				break;
			}
		}
	}

	protected override void WndProc(ref Message m)
	{
		if (m.Msg == 786)
		{
			int key = m.WParam.ToInt32();
			if (_targets.TryGetValue(key, out var value))
			{
				ToggleTarget(value);
			}
		}
		base.WndProc(ref m);
	}

	private static void ToggleTarget(Control target)
	{
		if (target == null || target.IsDisposed)
		{
			return;
		}
		if (target.InvokeRequired)
		{
			try
			{
				target.BeginInvoke(new Action<Control>(ToggleTarget), target);
				return;
			}
			catch
			{
				return;
			}
		}
		PropertyInfo property = target.GetType().GetProperty("Checked");
		if (property == null || !property.CanRead || !property.CanWrite)
		{
			return;
		}
		try
		{
			bool flag = Convert.ToBoolean(property.GetValue(target, null));
			property.SetValue(target, !flag, null);
		}
		catch
		{
		}
	}

	private static string GetMouseButtonName(MouseButtons button)
	{
		return button switch
		{
			MouseButtons.Left => "Mouse 1", 
			MouseButtons.Right => "Mouse 2", 
			MouseButtons.Middle => "Mouse 3", 
			MouseButtons.XButton1 => "Mouse 4", 
			MouseButtons.XButton2 => "Mouse 5", 
			_ => "Mouse", 
		};
	}

	private static void RemoveBinding(int id)
	{
		if (_instance != null && _instance.Handle != IntPtr.Zero)
		{
			UnregisterHotKey(_instance.Handle, id);
		}
		_targets.Remove(id);
		_buttons.Remove(id);
		_mouseBindings.Remove(id);
	}

	private static void ClearCapture()
	{
		_captureId = -1;
		_captureButton = null;
		_captureTarget = null;
		_captureForm = null;
	}

	public static void UnbindAll()
	{
		if (_instance != null && _instance.Handle != IntPtr.Zero)
		{
			foreach (int item in new List<int>(_targets.Keys))
			{
				UnregisterHotKey(_instance.Handle, item);
			}
		}
		_targets.Clear();
		_buttons.Clear();
		_mouseBindings.Clear();
		ClearCapture();
		if (_mouseHook != IntPtr.Zero)
		{
			UnhookWindowsHookEx(_mouseHook);
			_mouseHook = IntPtr.Zero;
		}
		_mouseProc = null;
	}
}
